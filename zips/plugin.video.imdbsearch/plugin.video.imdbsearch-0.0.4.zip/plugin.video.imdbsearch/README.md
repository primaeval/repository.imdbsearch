# plugin.video.imdbsearch
Kodi imdb advanced title search.
Launches meta4kodi.
Use settings for search parameters.
